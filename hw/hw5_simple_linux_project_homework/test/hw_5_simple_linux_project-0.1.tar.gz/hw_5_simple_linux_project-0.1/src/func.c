#include <stdio.h>
#include "header.h"

void print_hello() {
    printf("Hello from func.c\n");
}

void print_hello_from_hw() {
    printf("Homework #5 Simple Linux Project\n");
}
