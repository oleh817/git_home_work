#include <stdio.h>
#include "header.h"

int main() {
    printf("Hello from main.c\n");
    print_hello();
    print_hello_from_hw();
    return 0;
}
