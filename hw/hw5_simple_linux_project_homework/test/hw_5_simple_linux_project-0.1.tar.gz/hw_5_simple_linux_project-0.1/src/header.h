#ifndef HEADER_H
#define HEADER_H

void print_hello();
void print_hello_from_hw();

#endif